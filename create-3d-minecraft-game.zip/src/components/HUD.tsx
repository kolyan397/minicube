import { useEffect, useMemo, useRef, useState } from 'react';
import { useGame, playSound } from '../game/store';
import { ALL_BLOCKS, BLOCKS, getBlockTexture } from '../game/textures';
import { input, isMobileDevice } from '../game/input';

function useIcons() {
  const [icons, setIcons] = useState<Record<string, string>>({});
  useEffect(() => {
    const o: Record<string, string> = {};
    ALL_BLOCKS.forEach((id) => {
      try {
        o[id] = getBlockTexture(id).iconURL;
      } catch {
        o[id] = '';
      }
    });
    setIcons(o);
  }, []);
  return icons;
}

export default function HUD() {
  const started = useGame((s) => s.started);
  if (!started) return <MainMenu />;
  return (
    <>
      <Crosshair />
      <TopBar />
      <Hotbar />
      <HintBar />
      <InventoryModal />
      <PauseModal />
      <MobileControls />
    </>
  );
}

function MainMenu() {
  const newWorld = useGame((s) => s.newWorld);
  const loadWorld = useGame((s) => s.loadWorld);
  const set = useGame((s) => s.set);
  const [seedText, setSeedText] = useState(() => String(Math.floor(Math.random() * 90000 + 10000)));
  const [hasSave, setHasSave] = useState(false);
  const [loading, setLoading] = useState(false);
  const icons = useIcons();

  useEffect(() => {
    try {
      setHasSave(!!localStorage.getItem('mc3d-save-v1'));
    } catch {
      setHasSave(false);
    }
  }, []);

  const startNew = () => {
    setLoading(true);
    setTimeout(() => {
      const seed = parseInt(seedText.replace(/\D/g, '') || '12345', 10) || 12345;
      newWorld(seed);
      set({ started: true, showHelp: true, showPause: false, showInventory: false });
      // на десктопе сразу просим лок по первому клику — покажем подсказку
      setLoading(false);
      playSound('pick');
    }, 60);
  };

  const cont = () => {
    setLoading(true);
    setTimeout(() => {
      const ok = loadWorld();
      if (!ok) {
        newWorld(parseInt(seedText) || 12345);
      }
      set({ started: true, showHelp: false, showPause: false });
      setLoading(false);
    }, 60);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center overflow-hidden bg-[#0d0f14]">
      {/* фон — CSS воксели */}
      <div className="absolute inset-0 opacity-90" style={{
        background:
          'linear-gradient(180deg, #6aa9ff 0%, #8ec5ff 34%, #9bd07a 34.2%, #5da244 60%, #4a3a28 60.2%, #2b2118 100%)',
      }} />
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            'repeating-linear-gradient(0deg, rgba(0,0,0,0.12) 0 2px, transparent 2px 48px), repeating-linear-gradient(90deg, rgba(0,0,0,0.12) 0 2px, transparent 2px 48px)',
        }}
      />
      {/* пиксельные облака */}
      <div className="absolute top-[12%] left-[10%] h-6 w-44 bg-white/90 shadow-[8px_8px_0_rgba(255,255,255,0.5)]" />
      <div className="absolute top-[22%] right-[14%] h-5 w-56 bg-white/80" />
      {/* солнце */}
      <div className="absolute top-[10%] right-[22%] h-16 w-16 bg-[#ffdf5a] shadow-[0_0_60px_20px_rgba(255,223,90,0.6)]" />

      <div className="relative z-10 mx-4 w-full max-w-xl">
        <div className="mb-2 text-center">
          <div className="mc-title text-4xl sm:text-6xl">МАЙНКРАФТ</div>
          <div className="mc-title-sub text-lg sm:text-2xl">3D • В БРАУЗЕРЕ</div>
          <div className="mt-2 inline-block animate-pulse bg-[#ffff54] px-3 py-1 text-sm font-bold text-[#3f3f00] -rotate-3">
            100% кубики! Строй, копай, летай!
          </div>
        </div>

        <div className="mc-panel mt-6 p-4 sm:p-6">
          <div className="grid grid-cols-8 gap-1.5 opacity-90">
            {ALL_BLOCKS.slice(0, 16).map((id) => (
              <div key={id} className="aspect-square overflow-hidden border-2 border-black/60 bg-black/20">
                {icons[id] && <img src={icons[id]} alt={id} className="h-full w-full [image-rendering:pixelated]" />}
              </div>
            ))}
          </div>

          <label className="mt-4 block text-sm font-bold text-[#ddd]">
            Сид мира:
          </label>
          <div className="mt-1 flex gap-2">
            <input
              value={seedText}
              onChange={(e) => setSeedText(e.target.value)}
              className="mc-input flex-1"
              placeholder="12345"
              inputMode="numeric"
            />
            <button
              className="mc-btn mc-btn-small"
              onClick={() => setSeedText(String(Math.floor(Math.random() * 900000 + 10000)))}
            >
              🎲
            </button>
          </div>

          <button onClick={startNew} disabled={loading} className="mc-btn mt-4 w-full text-lg">
            {loading ? 'Генерация мира...' : '⛏ Создать новый мир'}
          </button>
          {hasSave && (
            <button onClick={cont} disabled={loading} className="mc-btn mt-2 w-full">
              ▶ Продолжить игру
            </button>
          )}
          <div className="mt-3 grid grid-cols-2 gap-2 text-[13px] leading-snug text-[#bdbdbd]">
            <div>🖱 <b>ЛКМ</b> — сломать<br/>🖱 <b>ПКМ</b> — поставить</div>
            <div>⌨ <b>WASD</b> — идти<br/>␣ <b>Пробел</b> — прыжок</div>
            <div>📦 <b>E</b> — инвентарь<br/>🕊 <b>F</b> — полёт</div>
            <div>🔢 <b>1–9</b> / колесо — выбор<br/>⚡ <b>Shift</b> — бег</div>
          </div>
          <div className="mt-3 text-center text-xs text-[#7f7f7f]">
            Мир сохраняется автоматически • работает на телефоне
          </div>
        </div>
        <div className="mt-3 text-center text-xs text-white/60">
          Фан-игра в стиле Minecraft • сделано на React + Three.js
        </div>
      </div>
    </div>
  );
}

function Crosshair() {
  const locked = useGame((s) => s.locked);
  const showInventory = useGame((s) => s.showInventory);
  const showPause = useGame((s) => s.showPause);
  const mobile = useMemo(() => isMobileDevice(), []);
  if (showInventory || showPause) return null;
  if (!locked && !mobile) return null;
  return (
    <div className="pointer-events-none absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2 mix-blend-difference">
      <div className="relative h-6 w-6">
        <div className="absolute left-1/2 top-0 h-full w-[2px] -translate-x-1/2 bg-white" />
        <div className="absolute left-0 top-1/2 h-[2px] w-full -translate-y-1/2 bg-white" />
      </div>
    </div>
  );
}

function TopBar() {
  const fps = useGame((s) => s.fps);
  const playerPos = useGame((s) => s.playerPos);
  const blockCount = useGame((s) => s.blockCount);
  const fly = useGame((s) => s.fly);
  const autoDay = useGame((s) => s.autoDay);
  const timeOfDay = useGame((s) => s.timeOfDay);
  const sound = useGame((s) => s.sound);
  const set = useGame((s) => s.set);
  const saveWorld = useGame((s) => s.saveWorld);
  const [savedTick, setSavedTick] = useState(0);

  const clock = useMemo(() => {
    const h = Math.floor(timeOfDay * 24);
    const m = Math.floor((timeOfDay * 24 - h) * 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }, [timeOfDay]);

  const isDay = timeOfDay > 0.22 && timeOfDay < 0.78;

  return (
    <div className="absolute left-0 right-0 top-0 z-20 flex items-start justify-between gap-2 p-2 sm:p-3">
      <div className="mc-chip">
        <div className="font-bold">⛏ {fps} FPS • 🧱 {blockCount}</div>
        <div className="text-[11px] opacity-80">
          XYZ: {playerPos[0].toFixed(1)} / {playerPos[1].toFixed(1)} / {playerPos[2].toFixed(1)}
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-end gap-1.5">
        <div className="mc-chip"> {isDay ? '☀️' : '🌙'} {clock}</div>
        <button
          className={`mc-btn mc-btn-small ${fly ? '!bg-[#5aa832] !text-white' : ''}`}
          title="Полёт (F)"
          onClick={() => set({ fly: !fly })}
        >
          🕊 {fly ? 'Полёт вкл' : 'Полёт'}
        </button>
        <button
          className="mc-btn mc-btn-small"
          title="День/ночь"
          onClick={() => set({ autoDay: !autoDay, timeOfDay: autoDay ? timeOfDay : 0.32 })}
        >
          {autoDay ? '⏸ Время' : '▶ Время'}
        </button>
        <button
          className="mc-btn mc-btn-small"
          onClick={() => set({ sound: !sound })}
        >
          {sound ? '🔊' : '🔇'}
        </button>
        <button
          className="mc-btn mc-btn-small"
          onClick={() => {
            saveWorld();
            setSavedTick(Date.now());
            setTimeout(() => setSavedTick(0), 1200);
          }}
        >
          {savedTick ? '✅ Сохранено!' : '💾'}
        </button>
        <button
          className="mc-btn mc-btn-small"
          onClick={() => {
            if (document.pointerLockElement) document.exitPointerLock();
            set({ showPause: true });
          }}
        >
          ☰
        </button>
      </div>
    </div>
  );
}

function Hotbar() {
  const hotbar = useGame((s) => s.hotbar);
  const selectedIndex = useGame((s) => s.selectedIndex);
  const setSelectedIndex = useGame((s) => s.setSelectedIndex);
  const showInventory = useGame((s) => s.showInventory);
  const showPause = useGame((s) => s.showPause);
  const icons = useIcons();
  if (showInventory || showPause) return null;

  return (
    <div className="absolute bottom-2 left-1/2 z-20 -translate-x-1/2 sm:bottom-4">
      <div className="flex gap-1 rounded-sm border-[3px] border-black/80 bg-black/50 p-1 backdrop-blur-sm">
        {hotbar.map((id, i) => (
          <button
            key={i}
            onClick={() => {
              setSelectedIndex(i);
              playSound('pick');
            }}
            className={`relative h-11 w-11 sm:h-14 sm:w-14 overflow-hidden border-2 transition-transform ${
              i === selectedIndex
                ? 'border-white scale-110 shadow-[0_0_0_2px_#000] z-10'
                : 'border-[#8b8b8b]/70 hover:border-white/70'
            } bg-[#8b8b8b]/30`}
          >
            {icons[id] ? (
              <img src={icons[id]} alt={BLOCKS[id].name} className="h-full w-full [image-rendering:pixelated]" />
            ) : (
              <div className="h-full w-full" style={{ background: BLOCKS[id].icon }} />
            )}
            <span className="absolute left-0.5 top-0 text-[10px] font-bold text-white drop-shadow-[1px_1px_0_#000]">
              {i + 1}
            </span>
            {i === selectedIndex && (
              <span className="absolute bottom-0 left-0 right-0 bg-black/70 px-1 text-[9px] leading-tight text-white truncate">
                {BLOCKS[id].name}
              </span>
            )}
          </button>
        ))}
      </div>
      <div className="mt-1 text-center text-xs font-bold text-white drop-shadow-[1px_1px_0_#000]">
        {BLOCKS[hotbar[selectedIndex]]?.name}
      </div>
    </div>
  );
}

function HintBar() {
  const locked = useGame((s) => s.locked);
  const showPause = useGame((s) => s.showPause);
  const showInventory = useGame((s) => s.showInventory);
  const showHelp = useGame((s) => s.showHelp);
  const set = useGame((s) => s.set);
  const mobile = useMemo(() => isMobileDevice(), []);
  if (showPause || showInventory) return null;
  if (mobile) return null;

  if (!locked) {
    return (
      <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/45 p-4">
        <div className="mc-panel max-w-md p-5 text-center">
          <div className="text-xl font-bold text-white">Кликни, чтобы играть ⛏</div>
          <p className="mt-2 text-sm text-[#ccc]">
            Управление захватится мышью.<br />
            <b>WASD</b> — движение • <b>Пробел</b> — прыжок • <b>ЛКМ</b> — сломать • <b>ПКМ</b> — поставить
          </p>
          <button
            className="mc-btn mt-4 w-full"
            onClick={() => {
              const c = document.querySelector('canvas');
              c?.requestPointerLock();
              set({ showPause: false, showHelp: false });
            }}
          >
            ▶ Играть
          </button>
          {showHelp && (
            <button className="mc-btn mt-2 w-full" onClick={() => set({ showHelp: false, showPause: true })}>
              ⚙ Настройки
            </button>
          )}
        </div>
      </div>
    );
  }
  return null;
}

function InventoryModal() {
  const show = useGame((s) => s.showInventory);
  const set = useGame((s) => s.set);
  const hotbar = useGame((s) => s.hotbar);
  const selectedIndex = useGame((s) => s.selectedIndex);
  const setHotbarSlot = useGame((s) => s.setHotbarSlot);
  const icons = useIcons();
  if (!show) return null;

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/60 p-3">
      <div className="mc-panel w-full max-w-lg p-4">
        <div className="flex items-center justify-between">
          <div className="text-lg font-bold text-white">🎒 Инвентарь <span className="text-xs font-normal text-[#aaa]">(E — закрыть)</span></div>
          <button className="mc-btn mc-btn-small" onClick={() => {
            set({ showInventory: false });
            const c = document.querySelector('canvas');
            if (!isMobileDevice()) c?.requestPointerLock();
          }}>✕</button>
        </div>
        <div className="mt-2 text-xs text-[#bbb]">Кликни по блоку — он встанет в выбранный слот ({selectedIndex + 1})</div>
        <div className="mt-3 grid grid-cols-4 gap-2 sm:grid-cols-4">
          {ALL_BLOCKS.map((id) => (
            <button
              key={id}
              onClick={() => {
                setHotbarSlot(selectedIndex, id);
                playSound('pick');
              }}
              className={`group flex flex-col items-center gap-1 border-2 p-2 transition-colors ${
                hotbar[selectedIndex] === id ? 'border-white bg-white/15' : 'border-black/60 bg-black/30 hover:border-white/60'
              }`}
            >
              <div className="h-12 w-12 overflow-hidden border border-black/50">
                {icons[id] ? (
                  <img src={icons[id]} alt={id} className="h-full w-full [image-rendering:pixelated]" />
                ) : (
                  <div className="h-full w-full" style={{ background: BLOCKS[id].icon }} />
                )}
              </div>
              <div className="text-[11px] font-bold leading-tight text-[#ddd] group-hover:text-white">{BLOCKS[id].name}</div>
            </button>
          ))}
        </div>
        <div className="mt-3 flex gap-1">
          {hotbar.map((id, i) => (
            <div key={i} className={`h-8 flex-1 overflow-hidden border-2 ${i === selectedIndex ? 'border-white' : 'border-black/60'}`}>
              {icons[id] && <img src={icons[id]} className="h-full w-full object-cover [image-rendering:pixelated]" alt="" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PauseModal() {
  const show = useGame((s) => s.showPause);
  const set = useGame((s) => s.set);
  const newWorld = useGame((s) => s.newWorld);
  const saveWorld = useGame((s) => s.saveWorld);
  const sensitivity = useGame((s) => s.sensitivity);
  const fov = useGame((s) => s.fov);
  const autoDay = useGame((s) => s.autoDay);
  const timeOfDay = useGame((s) => s.timeOfDay);
  const fly = useGame((s) => s.fly);
  const sound = useGame((s) => s.sound);
  const seed = useGame((s) => s.seed);
  const broken = useGame((s) => s.broken);
  const placed = useGame((s) => s.placed);
  const [confirmNew, setConfirmNew] = useState(false);
  if (!show) return null;

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/60 p-3">
      <div className="mc-panel w-full max-w-md p-5">
        <div className="text-center text-2xl font-bold text-white">⏸ Пауза</div>
        <div className="mt-1 text-center text-xs text-[#999]">Сид: {seed} • Сломано: {broken} • Поставлено: {placed}</div>

        <button
          className="mc-btn mt-4 w-full"
          onClick={() => {
            set({ showPause: false, showHelp: false });
            const c = document.querySelector('canvas');
            if (!isMobileDevice()) c?.requestPointerLock();
          }}
        >
          ▶ Продолжить
        </button>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <button className="mc-btn" onClick={() => { saveWorld(); playSound('pick'); }}>💾 Сохранить</button>
          <button className="mc-btn" onClick={() => set({ showInventory: true, showPause: false })}>🎒 Инвентарь</button>
        </div>

        <div className="mt-4 space-y-3 border-t border-white/10 pt-3 text-sm text-[#ddd]">
          <label className="block">
            <span className="font-bold">🖱 Чувствительность: {sensitivity.toFixed(1)}</span>
            <input type="range" min={0.3} max={2.5} step={0.1} value={sensitivity}
              onChange={(e) => set({ sensitivity: parseFloat(e.target.value) })}
              className="w-full accent-green-500" />
          </label>
          <label className="block">
            <span className="font-bold">👁 Поле зрения: {fov}°</span>
            <input type="range" min={60} max={110} step={1} value={fov}
              onChange={(e) => set({ fov: parseInt(e.target.value) })}
              className="w-full accent-green-500" />
          </label>
          <label className="block">
            <span className="font-bold">🕐 Время суток: {Math.floor(timeOfDay * 24)}:00 {autoDay ? '(авто)' : ''}</span>
            <input type="range" min={0} max={1} step={0.01} value={timeOfDay}
              onChange={(e) => set({ timeOfDay: parseFloat(e.target.value), autoDay: false })}
              className="w-full accent-yellow-500" />
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button className={`mc-btn mc-btn-small ${fly ? '!bg-[#5aa832]' : ''}`} onClick={() => set({ fly: !fly })}>🕊 Полёт</button>
            <button className="mc-btn mc-btn-small" onClick={() => set({ autoDay: !autoDay })}>{autoDay ? '⏸ Стоп' : '▶ День'}</button>
            <button className="mc-btn mc-btn-small" onClick={() => set({ sound: !sound })}>{sound ? '🔊 Звук' : '🔇 Тихо'}</button>
          </div>
        </div>

        {!confirmNew ? (
          <button className="mc-btn mt-3 w-full !bg-[#7a2e2e]" onClick={() => setConfirmNew(true)}>🌍 Новый мир...</button>
        ) : (
          <div className="mt-3 border border-red-500/50 bg-red-950/40 p-2 text-center">
            <div className="text-sm font-bold text-red-200">Точно создать новый мир? Текущий сотрётся!</div>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button className="mc-btn !bg-[#a83232]" onClick={() => {
                newWorld();
                set({ showPause: false });
                const c = document.querySelector('canvas');
                if (!isMobileDevice()) c?.requestPointerLock();
                setConfirmNew(false);
              }}>Да, новый!</button>
              <button className="mc-btn" onClick={() => setConfirmNew(false)}>Отмена</button>
            </div>
          </div>
        )}
        <button className="mc-btn mt-2 w-full" onClick={() => {
          saveWorld();
          if (document.pointerLockElement) document.exitPointerLock();
          set({ started: false, showPause: false });
        }}>🏠 В главное меню</button>

        <div className="mt-3 text-xs leading-relaxed text-[#888]">
          <b className="text-[#bbb]">Управление:</b> WASD — идти, Пробел — прыжок, Shift — бег,
          F — полёт (в полёте Space вверх / Shift вниз), E — инвентарь, 1–9 — блоки,
          ЛКМ — сломать, ПКМ — поставить, колесо — выбор
        </div>
      </div>
    </div>
  );
}

// ---------- Мобильное управление ----------
function MobileControls() {
  const showInventory = useGame((s) => s.showInventory);
  const showPause = useGame((s) => s.showPause);
  const fly = useGame((s) => s.fly);
  const set = useGame((s) => s.set);
  const [isMobile] = useState(() => isMobileDevice());
  const joyRef = useRef<HTMLDivElement>(null);
  const joyActive = useRef<number | null>(null);
  const joyCenter = useRef<[number, number]>([0, 0]);
  const [joyPos, setJoyPos] = useState<[number, number]>([0, 0]);
  const lookRef = useRef<{ id: number; x: number; y: number } | null>(null);

  useEffect(() => {
    if (!isMobile) return;
    const onTouchEnd = () => {
      input.joyX = 0;
      input.joyY = 0;
      setJoyPos([0, 0]);
      joyActive.current = null;
      lookRef.current = null;
      input.breakHeld = false;
      input.placeHeld = false;
    };
    window.addEventListener('touchend', onTouchEnd);
    window.addEventListener('touchcancel', onTouchEnd);
    return () => {
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [isMobile]);

  if (!isMobile || showInventory || showPause) return null;

  return (
    <>
      {/* зона взгляда — весь экран справа */}
      <div
        className="absolute inset-0 z-10"
        style={{ touchAction: 'none' }}
        onTouchStart={(e) => {
          for (const t of Array.from(e.changedTouches)) {
            // если тач в левой трети и джойстик — это джойстик
            if (t.clientX < window.innerWidth * 0.4 && t.clientY > window.innerHeight * 0.45) continue;
            if (lookRef.current) continue;
            lookRef.current = { id: t.identifier, x: t.clientX, y: t.clientY };
          }
        }}
        onTouchMove={(e) => {
          for (const t of Array.from(e.changedTouches)) {
            if (lookRef.current && t.identifier === lookRef.current.id) {
              input.lookDX += t.clientX - lookRef.current.x;
              input.lookDY += t.clientY - lookRef.current.y;
              lookRef.current.x = t.clientX;
              lookRef.current.y = t.clientY;
            }
          }
        }}
        onTouchEnd={(e) => {
          for (const t of Array.from(e.changedTouches)) {
            if (lookRef.current && t.identifier === lookRef.current.id) lookRef.current = null;
          }
        }}
      />
      {/* джойстик */}
      <div className="absolute bottom-24 left-4 z-20 select-none" style={{ touchAction: 'none' }}>
        <div
          ref={joyRef}
          className="relative h-32 w-32 rounded-full border-2 border-white/40 bg-black/30 backdrop-blur-sm"
          onTouchStart={(e) => {
            e.stopPropagation();
            const t = e.changedTouches[0];
            joyActive.current = t.identifier;
            const r = joyRef.current?.getBoundingClientRect();
            if (r) joyCenter.current = [r.left + r.width / 2, r.top + r.height / 2];
          }}
          onTouchMove={(e) => {
            e.stopPropagation();
            for (const t of Array.from(e.changedTouches)) {
              if (t.identifier !== joyActive.current) continue;
              const dx = t.clientX - joyCenter.current[0];
              const dy = t.clientY - joyCenter.current[1];
              const max = 44;
              const len = Math.hypot(dx, dy) || 1;
              const cl = Math.min(len, max);
              const nx = (dx / len) * cl;
              const ny = (dy / len) * cl;
              setJoyPos([nx, ny]);
              input.joyX = nx / max;
              input.joyY = ny / max;
            }
          }}
          onTouchEnd={(e) => {
            e.stopPropagation();
            for (const t of Array.from(e.changedTouches)) {
              if (t.identifier === joyActive.current) {
                joyActive.current = null;
                input.joyX = 0;
                input.joyY = 0;
                setJoyPos([0, 0]);
              }
            }
          }}
        >
          <div
            className="absolute left-1/2 top-1/2 h-14 w-14 rounded-full border-2 border-white/70 bg-white/40"
            style={{ transform: `translate(calc(-50% + ${joyPos[0]}px), calc(-50% + ${joyPos[1]}px))` }}
          />
        </div>
      </div>
      {/* кнопки действий */}
      <div className="absolute bottom-24 right-3 z-20 flex flex-col items-end gap-2">
        <div className="flex gap-2">
          <button
            className="mc-btn mc-btn-round"
            onTouchStart={(e) => { e.preventDefault(); input.jumpHeld = true; }}
            onTouchEnd={() => (input.jumpHeld = false)}
          >
            ⬆
          </button>
          <button
            className="mc-btn mc-btn-round"
            onClick={() => set({ fly: !fly })}
            style={{ background: fly ? '#5aa832' : undefined }}
          >
            🕊
          </button>
        </div>
        <div className="flex gap-2">
          <button
            className="mc-btn mc-btn-round !text-2xl"
            onTouchStart={(e) => { e.preventDefault(); input.breakHeld = true; }}
            onTouchEnd={() => (input.breakHeld = false)}
          >
            ⛏
          </button>
          <button
            className="mc-btn mc-btn-round !text-2xl"
            onTouchStart={(e) => { e.preventDefault(); input.placeHeld = true; }}
            onTouchEnd={() => (input.placeHeld = false)}
          >
            🧱
          </button>
        </div>
        <div className="flex gap-2">
          <button className="mc-btn mc-btn-small" onClick={() => set({ showInventory: true })}>🎒</button>
          <button
            className="mc-btn mc-btn-small"
            onTouchStart={(e) => { e.preventDefault(); input.sprintHeld = true; }}
            onTouchEnd={() => (input.sprintHeld = false)}
          >
            ⚡
          </button>
        </div>
      </div>
    </>
  );
}
