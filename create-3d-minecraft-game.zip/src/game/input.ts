// Общее состояние ввода (клавиатура + тач), чтобы HUD и Player видели одно и то же
export const input = {
  keys: new Set<string>(),
  joyX: 0, // -1..1
  joyY: 0,
  lookDX: 0,
  lookDY: 0,
  jumpHeld: false,
  sprintHeld: false,
  breakHeld: false,
  placeHeld: false,
  // одноразовые триггеры для мобильных кнопок
  consumeLook(): [number, number] {
    const dx = this.lookDX;
    const dy = this.lookDY;
    this.lookDX = 0;
    this.lookDY = 0;
    return [dx, dy];
  },
};

export function isMobileDevice() {
  if (typeof window === 'undefined') return false;
  return (
    'ontouchstart' in window ||
    navigator.maxTouchPoints > 0 ||
    window.innerWidth < 820
  );
}
