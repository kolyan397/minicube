import type { BlockId } from './textures';

export const WORLD_SIZE = 64; // 64x64
export const WATER_LEVEL = 7;

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hash2(x: number, z: number, seed: number) {
  let h = seed + x * 374761393 + z * 668265263;
  h = (h ^ (h >> 13)) * 1274126177;
  return ((h ^ (h >> 16)) >>> 0) / 4294967295;
}

function smooth(t: number) {
  return t * t * (3 - 2 * t);
}

function valueNoise(x: number, z: number, seed: number) {
  const xi = Math.floor(x);
  const zi = Math.floor(z);
  const xf = x - xi;
  const zf = z - zi;
  const a = hash2(xi, zi, seed);
  const b = hash2(xi + 1, zi, seed);
  const c = hash2(xi, zi + 1, seed);
  const d = hash2(xi + 1, zi + 1, seed);
  const u = smooth(xf);
  const v = smooth(zf);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

function fbm(x: number, z: number, seed: number) {
  return (
    valueNoise(x * 0.06, z * 0.06, seed) * 0.55 +
    valueNoise(x * 0.15 + 100, z * 0.15 + 100, seed + 7) * 0.3 +
    valueNoise(x * 0.35 + 200, z * 0.35 + 200, seed + 13) * 0.15
  );
}

export function terrainHeight(x: number, z: number, seed: number) {
  const n = fbm(x, z, seed);
  // 5..13
  let h = Math.floor(5 + n * 9);
  // выравнивание под спавн
  const d = Math.sqrt(x * x + z * z);
  if (d < 9) {
    const t = d / 9;
    const flat = 9;
    h = Math.round(flat * (1 - t) + h * t);
  }
  return h;
}

export interface GeneratedWorld {
  blocks: Record<string, BlockId>;
  spawn: [number, number, number];
  seed: number;
}

export function key(x: number, y: number, z: number) {
  return `${x},${y},${z}`;
}

export function generateWorld(seed = Math.floor(Math.random() * 999999)): GeneratedWorld {
  const blocks: Record<string, BlockId> = {};
  const half = Math.floor(WORLD_SIZE / 2);
  const rnd = mulberry32(seed);

  const heights: number[][] = [];

  for (let x = -half; x < half; x++) {
    const row: number[] = [];
    for (let z = -half; z < half; z++) {
      const h = terrainHeight(x, z, seed);
      row.push(h);
      // слои
      for (let y = 0; y <= h; y++) {
        let b: BlockId = 'stone';
        if (y === 0) b = 'bedrock';
        else if (y === h) {
          if (h <= WATER_LEVEL + 1) b = 'sand';
          else {
            // снежные вершины
            if (h >= 12 && rnd() > 0.6) b = 'snow';
            else b = 'grass';
          }
        } else if (y > h - 4) {
          if (h <= WATER_LEVEL + 1) b = 'sand';
          else b = 'dirt';
        } else {
          // руды
          const r = rnd();
          if (r < 0.02) b = 'coal_ore';
          else if (r < 0.025) b = 'brick_moss';
          else b = 'stone';
        }
        blocks[key(x, y, z)] = b;
      }
      // вода
      if (h < WATER_LEVEL) {
        for (let y = h + 1; y <= WATER_LEVEL; y++) {
          blocks[key(x, y, z)] = 'water';
        }
      }
    }
    heights.push(row);
  }

  // деревья
  let trees = 0;
  for (let x = -half + 2; x < half - 2; x++) {
    for (let z = -half + 2; z < half - 2; z++) {
      const h = terrainHeight(x, z, seed);
      if (h <= WATER_LEVEL + 1) continue;
      if (Math.sqrt(x * x + z * z) < 6) continue;
      const r = rnd();
      if (r < 0.018 && trees < 70) {
        const th = 4 + Math.floor(rnd() * 2);
        // ствол
        for (let i = 1; i <= th; i++) {
          blocks[key(x, h + i, z)] = 'log';
        }
        // листва
        for (let dx = -2; dx <= 2; dx++) {
          for (let dz = -2; dz <= 2; dz++) {
            for (let dy = -1; dy <= 1; dy++) {
              if (Math.abs(dx) === 2 && Math.abs(dz) === 2) {
                if (rnd() > 0.4) continue;
              }
              const lx = x + dx;
              const ly = h + th + dy;
              const lz = z + dz;
              const k = key(lx, ly, lz);
              if (!blocks[k]) blocks[k] = 'leaves';
            }
          }
        }
        // верхушка
        blocks[key(x, h + th + 2, z)] = 'leaves';
        trees++;
      }
    }
  }

  // стартовая площадка: небольшая поляна + сундук? делаем домик-приветствие из досок рядом со спавном
  const sh = terrainHeight(0, 0, seed);
  const spawn: [number, number, number] = [0.5, sh + 2.5, 6.5];

  // маленький причал/дом для красоты в отдалении
  const hx = 8;
  const hz = -6;
  const hh = terrainHeight(hx, hz, seed);
  if (hh > WATER_LEVEL + 1) {
    for (let dx = 0; dx < 5; dx++) {
      for (let dz = 0; dz < 4; dz++) {
        blocks[key(hx + dx, hh + 1, hz + dz)] = 'planks';
        if (dx === 0 || dx === 4 || dz === 0 || dz === 3) {
          blocks[key(hx + dx, hh + 2, hz + dz)] = 'log';
          blocks[key(hx + dx, hh + 3, hz + dz)] = 'log';
        } else {
          // воздух внутри
        }
      }
    }
    // крыша
    for (let dx = -1; dx < 6; dx++) {
      for (let dz = -1; dz < 5; dz++) {
        blocks[key(hx + dx, hh + 4, hz + dz)] = 'planks';
      }
    }
    // окно стекло + светокамень внутри
    blocks[key(hx + 2, hh + 2, hz + 0)] = 'glass';
    blocks[key(hx + 2, hh + 3, hz + 3)] = 'glow';
  }

  return { blocks, spawn, seed };
}

export function getBlockFromMap(
  blocks: Record<string, BlockId>,
  x: number,
  y: number,
  z: number
): BlockId | undefined {
  return blocks[`${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`];
}
