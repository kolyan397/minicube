import { useLayoutEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useGame, aimState } from './store';
import { BLOCKS, getBlockTexture, type BlockId } from './textures';

function isOpaque(id: BlockId | undefined) {
  if (!id) return false;
  const def = BLOCKS[id];
  if (!def) return false;
  if (id === 'leaves' || id === 'glass' || id === 'water') return false;
  return def.solid;
}

const dummy = new THREE.Object3D();

function InstancedBlocks({
  type,
  positions,
}: {
  type: BlockId;
  positions: [number, number, number][];
}) {
  const ref = useRef<THREE.InstancedMesh>(null!);

  const mats = useMemo(() => {
    const tex = getBlockTexture(type);
    const def = BLOCKS[type];
    const mk = (t: THREE.Texture | undefined, extra = {}) => {
      if (!t) return null;
      return new THREE.MeshLambertMaterial({
        map: t,
        transparent: !!def.transparent,
        opacity: def.opacity ?? 1,
        alphaTest: type === 'leaves' ? 0.3 : type === 'glass' ? 0.05 : 0,
        side: THREE.FrontSide,
        emissive: def.glow ? new THREE.Color('#7a4d00') : new THREE.Color('#000000'),
        emissiveIntensity: def.glow ? 0.55 : 0,
        depthWrite: type === 'water' ? false : true,
        ...extra,
      });
    };
    if (type === 'grass') {
      const side = mk(tex.side ?? tex.map)!;
      const top = mk(tex.top)!;
      const bottom = mk(tex.bottom ?? tex.map)!;
      return [side, side, top, bottom, side, side];
    }
    if (type === 'log') {
      const side = mk(tex.side ?? tex.map)!;
      const top = mk(tex.top)!;
      return [side, side, top, top, side, side];
    }
    return mk(tex.map)!;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    for (let i = 0; i < positions.length; i++) {
      const [x, y, z] = positions[i];
      dummy.position.set(x + 0.5, y + 0.5, z + 0.5);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.count = positions.length;
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
  }, [positions]);

  const geom = useMemo(() => new THREE.BoxGeometry(1, 1, 1), []);

  if (positions.length === 0) return null;

  return (
    <instancedMesh
      ref={ref}
      args={[geom, mats, Math.max(positions.length, 1)]}
      frustumCulled={false}
      material={mats}
    />
  );
}

export default function Voxels() {
  const blocks = useGame((s) => s.blocks);

  const grouped = useMemo(() => {
    const groups = {} as Record<BlockId, [number, number, number][]>;
    (Object.keys(BLOCKS) as BlockId[]).forEach((k) => (groups[k] = []));
    for (const k in blocks) {
      const type = blocks[k] as BlockId;
      // парсим ключ быстро
      const comma1 = k.indexOf(',');
      const comma2 = k.indexOf(',', comma1 + 1);
      const x = parseInt(k.slice(0, comma1), 10);
      const y = parseInt(k.slice(comma1 + 1, comma2), 10);
      const z = parseInt(k.slice(comma2 + 1), 10);

      // отсечение скрытых блоков
      const up = blocks[`${x},${y + 1},${z}`];
      const down = blocks[`${x},${y - 1},${z}`];
      const nx1 = blocks[`${x + 1},${y},${z}`];
      const nx2 = blocks[`${x - 1},${y},${z}`];
      const nz1 = blocks[`${x},${y},${z + 1}`];
      const nz2 = blocks[`${x},${y},${z - 1}`];
      if (
        isOpaque(up) &&
        isOpaque(down) &&
        isOpaque(nx1) &&
        isOpaque(nx2) &&
        isOpaque(nz1) &&
        isOpaque(nz2)
      ) {
        continue;
      }
      // воду под водой не рендерим верхние слои? если сверху вода — пропускаем боковые? упрощённо: если вода и сверху вода — всё равно рендерим (нужно для поверхности)
      if (type === 'water' && isOpaque(up) === false && up === 'water') {
        // оставляем только верхний слой воды для производительности
        // пропускаем если сверху тоже вода и соседние тоже вода? оставим как есть для простоты — но пропустим полностью скрытую
        const surroundWater =
          nx1 === 'water' && nx2 === 'water' && nz1 === 'water' && nz2 === 'water';
        if (surroundWater) continue;
      }
      groups[type]?.push([x, y, z]);
    }
    return groups;
  }, [blocks]);

  return (
    <group>
      {(Object.keys(groupsSafe(grouped)) as BlockId[]).map((type) => (
        <InstancedBlocks key={type} type={type} positions={grouped[type]} />
      ))}
      <Highlight />
      <Particles />
    </group>
  );
}

function groupsSafe(g: Record<string, unknown>) {
  return g;
}

function Highlight() {
  const boxRef = useRef<THREE.Mesh>(null!);
  const lineRef = useRef<THREE.LineSegments>(null!);

  const geom = useMemo(() => new THREE.BoxGeometry(1.002, 1.002, 1.002), []);
  const edge = useMemo(() => new THREE.EdgesGeometry(geom), [geom]);

  useFrame(() => {
    const t = aimState.target;
    if (!t) {
      if (boxRef.current) boxRef.current.visible = false;
      if (lineRef.current) lineRef.current.visible = false;
      return;
    }
    if (boxRef.current) {
      boxRef.current.visible = true;
      boxRef.current.position.set(t.x + 0.5, t.y + 0.5, t.z + 0.5);
    }
    if (lineRef.current) {
      lineRef.current.visible = true;
      lineRef.current.position.set(t.x + 0.5, t.y + 0.5, t.z + 0.5);
    }
  });

  return (
    <group>
      <mesh ref={boxRef} geometry={geom} visible={false}>
        <meshBasicMaterial color="#000000" transparent opacity={0.18} depthWrite={false} />
      </mesh>
      <lineSegments ref={lineRef} geometry={edge} visible={false}>
        <lineBasicMaterial color="#111111" transparent opacity={0.9} />
      </lineSegments>
    </group>
  );
}

function Particles() {
  const particles = useGame((s) => s.particles);
  const geom = useMemo(() => new THREE.BoxGeometry(0.12, 0.12, 0.12), []);
  return (
    <group>
      {particles.map((p) => (
        <mesh key={p.id} geometry={geom} position={p.pos}>
          <meshBasicMaterial color={p.color} transparent opacity={Math.min(1, p.life * 2)} />
        </mesh>
      ))}
    </group>
  );
}
