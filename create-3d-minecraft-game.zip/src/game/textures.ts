import * as THREE from 'three';

// Типы блоков
export type BlockId =
  | 'grass'
  | 'dirt'
  | 'stone'
  | 'cobble'
  | 'bedrock'
  | 'sand'
  | 'log'
  | 'leaves'
  | 'planks'
  | 'glass'
  | 'brick'
  | 'water'
  | 'glow'
  | 'snow'
  | 'coal_ore'
  | 'brick_moss';

export interface BlockDef {
  id: BlockId;
  name: string;
  solid: boolean;
  transparent?: boolean;
  opacity?: number;
  glow?: boolean;
  icon: string; // css color fallback
}

export const BLOCKS: Record<BlockId, BlockDef> = {
  grass: { id: 'grass', name: 'Дёрн', solid: true, icon: '#6abe30' },
  dirt: { id: 'dirt', name: 'Земля', solid: true, icon: '#8a5f3c' },
  stone: { id: 'stone', name: 'Камень', solid: true, icon: '#7d7d7d' },
  cobble: { id: 'cobble', name: 'Булыжник', solid: true, icon: '#6f6f6f' },
  bedrock: { id: 'bedrock', name: 'Коренная порода', solid: true, icon: '#2b2b2b' },
  sand: { id: 'sand', name: 'Песок', solid: true, icon: '#e3d79b' },
  log: { id: 'log', name: 'Бревно дуба', solid: true, icon: '#6b4f2a' },
  leaves: { id: 'leaves', name: 'Листва', solid: true, transparent: true, opacity: 0.95, icon: '#3b7d2e' },
  planks: { id: 'planks', name: 'Доски', solid: true, icon: '#b08a4f' },
  glass: { id: 'glass', name: 'Стекло', solid: true, transparent: true, opacity: 0.35, icon: '#cfeef5' },
  brick: { id: 'brick', name: 'Кирпичи', solid: true, icon: '#a5533e' },
  water: { id: 'water', name: 'Вода', solid: false, transparent: true, opacity: 0.7, icon: '#3b6fe0' },
  glow: { id: 'glow', name: 'Светокамень', solid: true, glow: true, icon: '#ffcf4d' },
  snow: { id: 'snow', name: 'Снег', solid: true, icon: '#eef4f8' },
  coal_ore: { id: 'coal_ore', name: 'Угольная руда', solid: true, icon: '#4a4a4a' },
  brick_moss: { id: 'brick_moss', name: 'Мшистый камень', solid: true, icon: '#6e7f5a' },
};

export const HOTBAR_DEFAULT: BlockId[] = [
  'grass',
  'dirt',
  'stone',
  'cobble',
  'planks',
  'log',
  'leaves',
  'glass',
  'brick',
];

export const ALL_BLOCKS: BlockId[] = Object.keys(BLOCKS) as BlockId[];

// ---------- Процедурные пиксельные текстуры ----------
function rand(seedObj: { s: number }) {
  seedObj.s = (seedObj.s * 16807) % 2147483647;
  return (seedObj.s - 1) / 2147483646;
}

function makeCanvas(size = 16): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  return [c, ctx];
}

function noiseFill(
  ctx: CanvasRenderingContext2D,
  size: number,
  base: string,
  speckles: string[],
  density = 90,
  seed = 1234
) {
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, size, size);
  const s = { s: seed };
  for (let i = 0; i < density; i++) {
    const x = Math.floor(rand(s) * size);
    const y = Math.floor(rand(s) * size);
    ctx.fillStyle = speckles[Math.floor(rand(s) * speckles.length)];
    ctx.fillRect(x, y, 1, 1);
    // иногда 2x1 для фактуры
    if (rand(s) > 0.7) ctx.fillRect((x + 1) % size, y, 1, 1);
  }
}

function toTexture(canvas: HTMLCanvasElement): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(canvas);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.colorSpace = THREE.SRGBColorSpace;
  t.generateMipmaps = false;
  return t;
}

export interface BlockTextures {
  map: THREE.CanvasTexture;
  top?: THREE.CanvasTexture;
  side?: THREE.CanvasTexture;
  bottom?: THREE.CanvasTexture;
  iconURL: string;
}

let cache: Partial<Record<BlockId, BlockTextures>> = {};

export function getBlockTexture(id: BlockId): BlockTextures {
  if (cache[id]) return cache[id]!;
  const S = 32; // повыше разрешение для чёткости
  let main: HTMLCanvasElement;
  let top: HTMLCanvasElement | undefined;
  let side: HTMLCanvasElement | undefined;
  let bottom: HTMLCanvasElement | undefined;

  const build = (
    painter: (ctx: CanvasRenderingContext2D, size: number) => void
  ) => {
    const [c, ctx] = makeCanvas(S);
    // масштабируем логику 16px на 32
    ctx.scale(2, 2);
    painter(ctx, 16);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    return c;
  };

  switch (id) {
    case 'grass': {
      top = build((ctx, n) => {
        noiseFill(ctx, n, '#6fbf3a', ['#5da92e', '#7ed44a', '#4f9c26', '#86dd55'], 140, 11);
      });
      bottom = build((ctx, n) => {
        noiseFill(ctx, n, '#7a5230', ['#6b4527', '#8a613a', '#5d3d22'], 130, 12);
      });
      side = build((ctx, n) => {
        noiseFill(ctx, n, '#7a5230', ['#6b4527', '#8a613a', '#5d3d22'], 120, 13);
        // дёрн сверху с рваным краем
        ctx.fillStyle = '#6fbf3a';
        ctx.fillRect(0, 0, n, 3);
        const s = { s: 99 };
        for (let x = 0; x < n; x++) {
          const d = 3 + Math.floor(rand(s) * 3);
          ctx.fillStyle = rand(s) > 0.5 ? '#6fbf3a' : '#5da92e';
          ctx.fillRect(x, 0, 1, d);
        }
        // блики
        noiseFill(ctx, n, 'rgba(0,0,0,0)', ['#5da92e', '#7ed44a'], 20, 14);
      });
      main = side;
      break;
    }
    case 'dirt': {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#7a5230', ['#6b4527', '#8a613a', '#5d3d22', '#957050'], 150, 21);
      });
      break;
    }
    case 'stone': {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#828282', ['#737373', '#8f8f8f', '#686868', '#9a9a9a'], 150, 31);
      });
      break;
    }
    case 'cobble': {
      main = build((ctx, n) => {
        ctx.fillStyle = '#5a5a5a';
        ctx.fillRect(0, 0, n, n);
        const s = { s: 41 };
        // камни-ячейки
        for (let i = 0; i < 5; i++) {
          for (let j = 0; j < 5; j++) {
            const g = 95 + Math.floor(rand(s) * 40);
            ctx.fillStyle = `rgb(${g},${g},${g})`;
            ctx.fillRect(i * 3 + 1, j * 3 + 1, 2, 2);
          }
        }
        ctx.fillStyle = '#3f3f3f';
        for (let k = 0; k < n; k++) {
          if (k % 3 === 0) {
            ctx.fillRect(k, 0, 1, n);
            ctx.fillRect(0, k, n, 1);
          }
        }
      });
      break;
    }
    case 'bedrock': {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#3a3a3a', ['#222', '#555', '#111', '#666'], 170, 51);
      });
      break;
    }
    case 'sand': {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#ddd09a', ['#d0c184', '#e8ddab', '#c4b478'], 160, 61);
      });
      break;
    }
    case 'log': {
      side = build((ctx, n) => {
        ctx.fillStyle = '#6b4f2a';
        ctx.fillRect(0, 0, n, n);
        for (let x = 0; x < n; x++) {
          ctx.fillStyle = x % 4 === 0 ? '#4e3820' : x % 4 === 2 ? '#7d5f36' : '#6b4f2a';
          ctx.fillRect(x, 0, 1, n);
        }
        noiseFill(ctx, n, 'rgba(0,0,0,0)', ['#3d2c17', '#8a6c42'], 40, 62);
      });
      top = build((ctx, n) => {
        ctx.fillStyle = '#b08a4f';
        ctx.fillRect(0, 0, n, n);
        ctx.strokeStyle = '#6b4f2a';
        ctx.lineWidth = 1;
        for (let r = 7; r > 0; r -= 2) {
          ctx.strokeRect(8 - r, 8 - r, r * 2, r * 2);
        }
        ctx.fillStyle = '#4e3820';
        ctx.fillRect(0, 0, n, 1);
        ctx.fillRect(0, n - 1, n, 1);
        ctx.fillRect(0, 0, 1, n);
        ctx.fillRect(n - 1, 0, 1, n);
      });
      bottom = top;
      main = side;
      break;
    }
    case 'leaves': {
      main = build((ctx, n) => {
        ctx.fillStyle = '#2f6b24';
        ctx.fillRect(0, 0, n, n);
        noiseFill(ctx, n, '#2f6b24', ['#3b7d2e', '#245a1c', '#4a9c3a', '#1d4a15'], 180, 71);
        // дырки
        const s = { s: 72 };
        ctx.fillStyle = 'rgba(15,35,10,0.9)';
        for (let i = 0; i < 18; i++) {
          ctx.fillRect(Math.floor(rand(s) * n), Math.floor(rand(s) * n), 1, 1);
        }
      });
      break;
    }
    case 'planks': {
      main = build((ctx, n) => {
        ctx.fillStyle = '#a67c3f';
        ctx.fillRect(0, 0, n, n);
        for (let y = 0; y < n; y += 4) {
          ctx.fillStyle = '#8a6530';
          ctx.fillRect(0, y, n, 1);
          ctx.fillStyle = '#b89055';
          ctx.fillRect(0, y + 1, n, 1);
        }
        // стыки
        ctx.fillStyle = '#5d4423';
        ctx.fillRect(4, 1, 1, 3);
        ctx.fillRect(11, 5, 1, 3);
        ctx.fillRect(7, 9, 1, 3);
        ctx.fillRect(13, 13, 1, 3);
        noiseFill(ctx, n, 'rgba(0,0,0,0)', ['#7a5a2e'], 30, 73);
      });
      break;
    }
    case 'glass': {
      main = build((ctx, n) => {
        ctx.clearRect(0, 0, n, n);
        ctx.fillStyle = 'rgba(210,240,250,0.55)';
        ctx.fillRect(0, 0, n, n);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, n, 1);
        ctx.fillRect(0, 0, 1, n);
        ctx.fillRect(n - 1, 0, 1, n);
        ctx.fillRect(0, n - 1, n, 1);
        // блик
        ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.fillRect(3, 10, 1, 3);
        ctx.fillRect(4, 9, 1, 3);
        ctx.fillRect(5, 8, 1, 3);
        ctx.fillRect(10, 3, 3, 1);
      });
      break;
    }
    case 'brick': {
      main = build((ctx, n) => {
        ctx.fillStyle = '#b5a89a';
        ctx.fillRect(0, 0, n, n);
        ctx.fillStyle = '#9e4a3a';
        const bh = 3;
        for (let y = 0; y < n; y += 4) {
          const off = (y / 4) % 2 === 0 ? 0 : 4;
          for (let x = -4; x < n + 4; x += 8) {
            ctx.fillStyle = '#9e4a3a';
            ctx.fillRect(x + off, y, 7, bh);
            ctx.fillStyle = '#b85c48';
            ctx.fillRect(x + off, y, 7, 1);
          }
        }
        noiseFill(ctx, n, 'rgba(0,0,0,0)', ['#7a3126'], 25, 81);
      });
      break;
    }
    case 'water': {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#2f5fd0', ['#3b6fe0', '#264fb5', '#4a80ff'], 120, 91);
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        for (let y = 2; y < n; y += 5) {
          for (let x = 0; x < n; x += 4) {
            ctx.fillRect(x + ((y * 3) % 4), y, 2, 1);
          }
        }
      });
      break;
    }
    case 'glow': {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#d89a2b', ['#ffcf4d', '#ffb52e', '#a86a1a', '#ffe28a'], 170, 101);
        ctx.fillStyle = '#fff3b0';
        ctx.fillRect(3, 3, 3, 3);
        ctx.fillRect(10, 10, 3, 3);
      });
      break;
    }
    case 'snow': {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#eef4f8', ['#dde8f0', '#ffffff', '#cbd9e3'], 110, 111);
      });
      break;
    }
    case 'coal_ore': {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#828282', ['#737373', '#8f8f8f', '#686868'], 120, 121);
        ctx.fillStyle = '#1c1c1c';
        const spots: [number, number][] = [
          [3, 4],
          [10, 3],
          [7, 9],
          [12, 11],
          [4, 12],
        ];
        spots.forEach(([x, y]) => {
          ctx.fillRect(x, y, 2, 2);
          ctx.fillStyle = '#333';
          ctx.fillRect(x, y, 1, 1);
          ctx.fillStyle = '#1c1c1c';
        });
      });
      break;
    }
    case 'brick_moss':
    default: {
      main = build((ctx, n) => {
        noiseFill(ctx, n, '#7a7a7a', ['#6b6b6b', '#8a8a8a', '#5d5d5d'], 130, 131);
        ctx.fillStyle = '#3f3f3f';
        for (let k = 0; k < n; k += 4) {
          ctx.fillRect(k, 0, 1, n);
          ctx.fillRect(0, k, n, 1);
        }
        noiseFill(ctx, n, 'rgba(0,0,0,0)', ['#4a7a3a', '#5d9c4a'], 50, 132);
      });
      break;
    }
  }

  const map = toTexture(main);
  const res: BlockTextures = {
    map,
    iconURL: main.toDataURL(),
  };
  if (top) {
    res.top = toTexture(top);
    if (id === 'grass' || id === 'log') res.iconURL = top.toDataURL();
  }
  if (side) res.side = toTexture(side);
  if (bottom) res.bottom = toTexture(bottom);

  cache[id] = res;
  return res;
}

export function clearTextureCache() {
  cache = {};
}
