import { create } from 'zustand';
import type { BlockId } from './textures';
import { HOTBAR_DEFAULT } from './textures';
import { generateWorld, key } from './worldgen';

export type Screen = 'menu' | 'playing';

interface Particle {
  id: number;
  pos: [number, number, number];
  vel: [number, number, number];
  color: string;
  life: number;
}

interface GameState {
  blocks: Record<string, BlockId>;
  seed: number;
  spawn: [number, number, number];
  worldSize: number;
  blockCount: number;

  hotbar: BlockId[];
  selectedIndex: number;
  selected: BlockId;

  started: boolean;
  locked: boolean;
  showInventory: boolean;
  showPause: boolean;
  showHelp: boolean;
  fly: boolean;
  autoDay: boolean;
  timeOfDay: number; // 0..1, 0.3 = утро
  sensitivity: number;
  fov: number;
  sound: boolean;
  renderDist: number;

  playerPos: [number, number, number];
  fps: number;
  broken: number;
  placed: number;

  particles: Particle[];
  lastAction: number;
  lockedOrMobile: (s: { locked: boolean }) => boolean;

  // actions
  newWorld: (seed?: number) => void;
  loadWorld: () => boolean;
  saveWorld: () => void;
  addBlock: (x: number, y: number, z: number, type: BlockId) => void;
  removeBlock: (x: number, y: number, z: number) => BlockId | undefined;
  getBlock: (x: number, y: number, z: number) => BlockId | undefined;

  setSelectedIndex: (i: number) => void;
  setSelected: (b: BlockId) => void;
  setHotbarSlot: (i: number, b: BlockId) => void;

  set: (p: Partial<GameState>) => void;
  pushParticles: (pos: [number, number, number], color: string) => void;
  tickParticles: (dt: number) => void;
}

let particleId = 1;

const SAVE_KEY = 'mc3d-save-v1';

export const useGame = create<GameState>((set, get) => ({
  blocks: {},
  seed: 12345,
  spawn: [0.5, 12, 6.5],
  worldSize: 64,
  blockCount: 0,

  hotbar: [...HOTBAR_DEFAULT],
  selectedIndex: 0,
  selected: HOTBAR_DEFAULT[0],

  started: false,
  locked: false,
  showInventory: false,
  showPause: false,
  showHelp: true,
  fly: false,
  autoDay: true,
  timeOfDay: 0.32,
  sensitivity: 1,
  fov: 75,
  sound: true,
  renderDist: 64,

  playerPos: [0, 12, 0],
  fps: 60,
  broken: 0,
  placed: 0,
  particles: [],
  lastAction: 0,
  lockedOrMobile: (s: { locked: boolean }) => {
    if (s.locked) return true;
    if (typeof window !== 'undefined' && 'ontouchstart' in window) return true;
    return true;
  },

  newWorld: (seed) => {
    const gen = generateWorld(seed);
    set({
      blocks: gen.blocks,
      seed: gen.seed,
      spawn: gen.spawn,
      playerPos: gen.spawn,
      blockCount: Object.keys(gen.blocks).length,
      broken: 0,
      placed: 0,
      particles: [],
    });
    get().saveWorld();
  },

  loadWorld: () => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return false;
      const data = JSON.parse(raw);
      if (!data.blocks || Object.keys(data.blocks).length < 100) return false;
      set({
        blocks: data.blocks,
        seed: data.seed ?? 12345,
        spawn: data.spawn ?? [0.5, 12, 6.5],
        hotbar: data.hotbar ?? [...HOTBAR_DEFAULT],
        selectedIndex: data.selectedIndex ?? 0,
        selected: data.hotbar?.[data.selectedIndex ?? 0] ?? HOTBAR_DEFAULT[0],
        blockCount: Object.keys(data.blocks).length,
        broken: data.broken ?? 0,
        placed: data.placed ?? 0,
      });
      return true;
    } catch {
      return false;
    }
  },

  saveWorld: () => {
    try {
      const s = get();
      localStorage.setItem(
        SAVE_KEY,
        JSON.stringify({
          blocks: s.blocks,
          seed: s.seed,
          spawn: s.spawn,
          hotbar: s.hotbar,
          selectedIndex: s.selectedIndex,
          broken: s.broken,
          placed: s.placed,
        })
      );
    } catch {}
  },

  addBlock: (x, y, z, type) => {
    const k = key(x, y, z);
    const { blocks } = get();
    if (blocks[k] === type) return;
    // нельзя ставить внутрь игрока? проверка грубая — пропустим, физика вытолкнет
    const next = { ...blocks, [k]: type };
    set((s) => ({
      blocks: next,
      blockCount: Object.keys(next).length,
      placed: s.placed + 1,
      lastAction: Date.now(),
    }));
  },

  removeBlock: (x, y, z) => {
    const k = key(x, y, z);
    const { blocks } = get();
    const cur = blocks[k];
    if (!cur) return undefined;
    if (cur === 'bedrock' && y === 0) return undefined; // дно не ломаем
    const next = { ...blocks };
    delete next[k];
    set((s) => ({
      blocks: next,
      blockCount: Object.keys(next).length,
      broken: s.broken + 1,
      lastAction: Date.now(),
    }));
    return cur;
  },

  getBlock: (x, y, z) => {
    return get().blocks[key(Math.floor(x), Math.floor(y), Math.floor(z))];
  },

  setSelectedIndex: (i) =>
    set((s) => ({
      selectedIndex: ((i % 9) + 9) % 9,
      selected: s.hotbar[((i % 9) + 9) % 9],
    })),
  setSelected: (b) =>
    set((s) => {
      const nb = [...s.hotbar];
      nb[s.selectedIndex] = b;
      return { hotbar: nb, selected: b };
    }),
  setHotbarSlot: (i, b) =>
    set((s) => {
      const nb = [...s.hotbar];
      nb[i] = b;
      return {
        hotbar: nb,
        selected: i === s.selectedIndex ? b : s.selected,
      };
    }),

  set: (p) => set(p),

  pushParticles: (pos, color) => {
    const arr: Particle[] = [];
    for (let i = 0; i < 14; i++) {
      arr.push({
        id: particleId++,
        pos: [pos[0] + 0.2 + Math.random() * 0.6, pos[1] + 0.2 + Math.random() * 0.6, pos[2] + 0.2 + Math.random() * 0.6],
        vel: [(Math.random() - 0.5) * 4, Math.random() * 4 + 1, (Math.random() - 0.5) * 4],
        color,
        life: 0.6 + Math.random() * 0.3,
      });
    }
    set((s) => ({ particles: [...s.particles.slice(-120), ...arr] }));
  },

  tickParticles: (dt) =>
    set((s) => {
      if (s.particles.length === 0) return s;
      const next = s.particles
        .map((p) => ({
          ...p,
          life: p.life - dt,
          vel: [p.vel[0], p.vel[1] - 12 * dt, p.vel[2]] as [number, number, number],
          pos: [
            p.pos[0] + p.vel[0] * dt,
            p.pos[1] + p.vel[1] * dt,
            p.pos[2] + p.vel[2] * dt,
          ] as [number, number, number],
        }))
        .filter((p) => p.life > 0);
      return { particles: next };
    }),
}));

// Мутабельное состояние прицела (чтобы не ререндерить каждый кадр)
export const aimState = {
  target: null as null | { x: number; y: number; z: number; nx: number; ny: number; nz: number },
};

// Звуки — процедурные, без файлов
let audioCtx: AudioContext | null = null;
export function playSound(kind: 'break' | 'place' | 'pick' | 'step' | 'splash') {
  try {
    const enabled = useGame.getState().sound;
    if (!enabled) return;
    if (!audioCtx) audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const ctx = audioCtx;
    const t = ctx.currentTime;
    if (kind === 'break') {
      const dur = 0.12;
      const buf = ctx.createBuffer(1, ctx.sampleRate * dur, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length) * 0.6;
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = 900 + Math.random() * 600;
      src.connect(f).connect(ctx.destination);
      src.start(t);
    } else if (kind === 'place') {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'square';
      o.frequency.setValueAtTime(220 + Math.random() * 80, t);
      o.frequency.exponentialRampToValueAtTime(110, t + 0.08);
      g.gain.setValueAtTime(0.18, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
      o.connect(g).connect(ctx.destination);
      o.start(t);
      o.stop(t + 0.1);
    } else if (kind === 'pick') {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(600, t);
      o.frequency.exponentialRampToValueAtTime(900, t + 0.07);
      g.gain.setValueAtTime(0.12, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
      o.connect(g).connect(ctx.destination);
      o.start(t);
      o.stop(t + 0.09);
    }
  } catch {}
}
