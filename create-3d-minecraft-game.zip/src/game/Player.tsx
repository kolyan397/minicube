import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { useGame, aimState, playSound } from './store';
import { BLOCKS, type BlockId } from './textures';
import { input } from './input';

const EYE = 1.62;
const HALF = 0.31;
const HEIGHT = 1.8;
const GRAV = 28;
const JUMP = 9.2;

function isSolid(blocks: Record<string, BlockId>, x: number, y: number, z: number) {
  const b = blocks[`${x},${y},${z}`];
  if (!b) return false;
  return BLOCKS[b]?.solid ?? true;
}

function collides(
  blocks: Record<string, BlockId>,
  px: number,
  py: number,
  pz: number
) {
  const x0 = Math.floor(px - HALF);
  const x1 = Math.floor(px + HALF);
  const y0 = Math.floor(py);
  const y1 = Math.floor(py + HEIGHT);
  const z0 = Math.floor(pz - HALF);
  const z1 = Math.floor(pz + HALF);
  for (let x = x0; x <= x1; x++)
    for (let y = y0; y <= y1; y++)
      for (let z = z0; z <= z1; z++) if (isSolid(blocks, x, y, z)) return true;
  return false;
}

function inWater(blocks: Record<string, BlockId>, px: number, py: number, pz: number) {
  const b =
    blocks[`${Math.floor(px)},${Math.floor(py + 0.4)},${Math.floor(pz)}`] ||
    blocks[`${Math.floor(px)},${Math.floor(py + 1.2)},${Math.floor(pz)}`];
  return b === 'water';
}

// DDA рейкаст по вокселям
function raycastVoxel(
  blocks: Record<string, BlockId>,
  origin: THREE.Vector3,
  dir: THREE.Vector3,
  maxDist = 7
) {
  let x = Math.floor(origin.x);
  let y = Math.floor(origin.y);
  let z = Math.floor(origin.z);
  const stepX = dir.x > 0 ? 1 : -1;
  const stepY = dir.y > 0 ? 1 : -1;
  const stepZ = dir.z > 0 ? 1 : -1;
  const tDeltaX = dir.x !== 0 ? Math.abs(1 / dir.x) : Infinity;
  const tDeltaY = dir.y !== 0 ? Math.abs(1 / dir.y) : Infinity;
  const tDeltaZ = dir.z !== 0 ? Math.abs(1 / dir.z) : Infinity;
  const distX =
    dir.x !== 0
      ? (stepX > 0 ? x + 1 - origin.x : origin.x - x) * tDeltaX
      : Infinity;
  const distY =
    dir.y !== 0
      ? (stepY > 0 ? y + 1 - origin.y : origin.y - y) * tDeltaY
      : Infinity;
  const distZ =
    dir.z !== 0
      ? (stepZ > 0 ? z + 1 - origin.z : origin.z - z) * tDeltaZ
      : Infinity;
  let tMaxX = distX;
  let tMaxY = distY;
  let tMaxZ = distZ;
  let nx = 0;
  let ny = 0;
  let nz = 0;
  let t = 0;
  for (let i = 0; i < 128; i++) {
    const k = `${x},${y},${z}`;
    const b = blocks[k];
    if (b && b !== 'water') {
      return { x, y, z, nx, ny, nz, block: b as BlockId, dist: t };
    }
    if (tMaxX < tMaxY && tMaxX < tMaxZ) {
      x += stepX;
      t = tMaxX;
      tMaxX += tDeltaX;
      nx = -stepX;
      ny = 0;
      nz = 0;
    } else if (tMaxY < tMaxZ) {
      y += stepY;
      t = tMaxY;
      tMaxY += tDeltaY;
      nx = 0;
      ny = -stepY;
      nz = 0;
    } else {
      z += stepZ;
      t = tMaxZ;
      tMaxZ += tDeltaZ;
      nx = 0;
      ny = 0;
      nz = -stepZ;
    }
    if (t > maxDist) return null;
  }
  return null;
}

export default function Player() {
  const camera = useThree((s) => s.camera);
  const gl = useThree((s) => s.gl);
  const pos = useRef(new THREE.Vector3(0.5, 14, 6.5));
  const vel = useRef(new THREE.Vector3());
  const yaw = useRef(Math.PI);
  const pitch = useRef(-0.1);
  const onGround = useRef(false);
  const keys = useRef<Set<string>>(new Set());
  const breakTimer = useRef(0);
  const placeTimer = useRef(0);
  const mouseHeld = useRef<{ left: boolean; right: boolean }>({ left: false, right: false });
  const frames = useRef(0);
  const fpsTime = useRef(0);
  const uiTick = useRef(0);
  const didInit = useRef(false);

  // инициализация спавна
  useEffect(() => {
    const s = useGame.getState();
    pos.current.set(s.spawn[0], s.spawn[1], s.spawn[2]);
    yaw.current = Math.PI;
    pitch.current = -0.08;
    didInit.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // подписка на новый мир — телепорт на спавн
  useEffect(() => {
    const unsub = useGame.subscribe((s, prev) => {
      if (s.spawn !== prev.spawn || s.seed !== prev.seed) {
        pos.current.set(s.spawn[0], s.spawn[1], s.spawn[2]);
        vel.current.set(0, 0, 0);
      }
    });
    return unsub;
  }, []);

  // ввод
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      const k = e.code;
      keys.current.add(k);
      input.keys.add(k);
      if (k === 'Space') input.jumpHeld = true;
      if (k === 'ShiftLeft' || k === 'ShiftRight') input.sprintHeld = true;

      const st = useGame.getState();
      if (!st.started) return;
      if (k === 'KeyF') {
        useGame.getState().set({ fly: !useGame.getState().fly });
        playSound('pick');
      }
      if (k === 'KeyE') {
        if (st.locked) document.exitPointerLock?.();
        st.set({ showInventory: !st.showInventory, showPause: false });
      }
      if (k === 'Escape') {
        // браузер сам выйдет из лок — покажем паузу
      }
      if (k.startsWith('Digit')) {
        const n = parseInt(k.slice(5), 10);
        if (n >= 1 && n <= 9) {
          st.setSelectedIndex(n - 1);
          playSound('pick');
        }
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keys.current.delete(e.code);
      input.keys.delete(e.code);
      if (e.code === 'Space') input.jumpHeld = false;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') input.sprintHeld = false;
    };
    const onMouseMove = (e: MouseEvent) => {
      const st = useGame.getState();
      if (document.pointerLockElement !== gl.domElement) return;
      if (!st.started || st.showInventory || st.showPause) return;
      const sens = 0.0023 * st.sensitivity;
      yaw.current -= e.movementX * sens;
      pitch.current -= e.movementY * sens;
      pitch.current = Math.max(-Math.PI / 2 + 0.01, Math.min(Math.PI / 2 - 0.01, pitch.current));
    };
    const onMouseDown = (e: MouseEvent) => {
      const st = useGame.getState();
      if (!st.started) return;
      // клик по канвасу без лока — залочить
      if (document.pointerLockElement !== gl.domElement) {
        if ((e.target as HTMLElement)?.closest('canvas')) {
          if (!st.showInventory && !st.showPause) {
            gl.domElement.requestPointerLock();
          }
        }
        return;
      }
      if (st.showInventory || st.showPause) return;
      if (e.button === 0) {
        mouseHeld.current.left = true;
        doBreak();
      }
      if (e.button === 2) {
        mouseHeld.current.right = true;
        doPlace();
      }
    };
    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) mouseHeld.current.left = false;
      if (e.button === 2) mouseHeld.current.right = false;
    };
    const onWheel = (e: WheelEvent) => {
      const st = useGame.getState();
      if (!st.started || !st.locked) return;
      if (st.showInventory) return;
      const dir = e.deltaY > 0 ? 1 : -1;
      st.setSelectedIndex(st.selectedIndex + dir);
    };
    const onLock = () => {
      const locked = document.pointerLockElement === gl.domElement;
      useGame.getState().set({ locked });
      if (!locked) {
        mouseHeld.current.left = false;
        mouseHeld.current.right = false;
        // если игра идёт и не открыт инвентарь — показать паузу
        const s = useGame.getState();
        if (s.started && !s.showInventory && !s.showHelp) {
          // небольшая задержка чтобы E не конфликтовало
          setTimeout(() => {
            const cur = useGame.getState();
            if (!cur.locked && cur.started && !cur.showInventory && document.pointerLockElement !== gl.domElement) {
              // показываем паузу только если это десктоп
              if (!('ontouchstart' in window)) cur.set({ showPause: true });
            }
          }, 120);
        }
      } else {
        useGame.getState().set({ showPause: false, showInventory: false });
      }
    };
    const onCtx = (e: Event) => e.preventDefault();

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('wheel', onWheel);
    document.addEventListener('pointerlockchange', onLock);
    gl.domElement.addEventListener('contextmenu', onCtx);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('wheel', onWheel);
      document.removeEventListener('pointerlockchange', onLock);
      gl.domElement.removeEventListener('contextmenu', onCtx);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gl]);

  const doBreak = () => {
    const t = aimState.target;
    if (!t) return;
    const st = useGame.getState();
    if (st.showInventory || st.showPause) return;
    const removed = st.removeBlock(t.x, t.y, t.z);
    if (removed) {
      playSound('break');
      const col = BLOCKS[removed]?.icon ?? '#888';
      st.pushParticles([t.x, t.y, t.z], col);
      // автосейв раз в ~20 действий
      if ((st.broken + st.placed) % 20 === 0) st.saveWorld();
    }
    breakTimer.current = 0;
  };

  const doPlace = () => {
    const t = aimState.target;
    if (!t) return;
    const st = useGame.getState();
    if (st.showInventory || st.showPause) return;
    const px = t.x + t.nx;
    const py = t.y + t.ny;
    const pz = t.z + t.nz;
    // не ставить в себя
    const p = pos.current;
    const overlap =
      px + 1 > p.x - HALF &&
      px < p.x + HALF &&
      pz + 1 > p.z - HALF &&
      pz < p.z + HALF &&
      py + 1 > p.y &&
      py < p.y + HEIGHT;
    const existing = st.getBlock(px, py, pz);
    if (existing && existing !== 'water') return;
    if (overlap && BLOCKS[st.selected]?.solid) return;
    if (py < 0 || py > 60) return;
    st.addBlock(px, py, pz, st.selected);
    playSound('place');
    placeTimer.current = 0;
    if ((st.broken + st.placed) % 20 === 0) st.saveWorld();
  };

  useFrame((_state, rawDt) => {
    const dt = Math.min(rawDt, 0.05);
    const st = useGame.getState();
    // пауза — не двигаем, но камеру всё равно ставим
    const paused = !st.started || st.showPause || st.showInventory;

    // мобильный взгляд
    const [ldx, ldy] = input.consumeLook();
    if (ldx !== 0 || ldy !== 0) {
      const sens = 0.0042 * st.sensitivity;
      yaw.current -= ldx * sens;
      pitch.current -= ldy * sens;
      pitch.current = Math.max(-Math.PI / 2 + 0.01, Math.min(Math.PI / 2 - 0.01, pitch.current));
    }

    // удержание кнопок сломать/поставить (десктоп + мобильные)
    if ((mouseHeld.current.left || input.breakHeld) && st.lockedOrMobile(st)) {
      breakTimer.current += dt;
      if (breakTimer.current > 0.22) doBreak();
    } else breakTimer.current = 0;
    if ((mouseHeld.current.right || input.placeHeld) && st.lockedOrMobile(st)) {
      placeTimer.current += dt;
      if (placeTimer.current > 0.22) doPlace();
    } else placeTimer.current = 0;

    // движение
    const k = keys.current;
    let fwd = 0;
    let strafe = 0;
    if (!paused) {
      if (k.has('KeyW') || k.has('ArrowUp')) fwd += 1;
      if (k.has('KeyS') || k.has('ArrowDown')) fwd -= 1;
      if (k.has('KeyA') || k.has('ArrowLeft')) strafe -= 1;
      if (k.has('KeyD') || k.has('ArrowRight')) strafe += 1;
      fwd += -input.joyY;
      strafe += input.joyX;
    }
    const len = Math.hypot(fwd, strafe);
    if (len > 1) {
      fwd /= len;
      strafe /= len;
    }

    const sprint = k.has('ShiftLeft') || k.has('ShiftRight') || input.sprintHeld || k.has('ControlLeft');
    const speed = st.fly ? (sprint ? 14 : 8) : sprint ? 7.2 : 4.6;

    const sin = Math.sin(yaw.current);
    const cos = Math.cos(yaw.current);
    // forward на плоскости
    const dirX = -sin * fwd + cos * strafe;
    const dirZ = -cos * fwd - sin * strafe;

    const blocks = st.blocks;
    const p = pos.current;
    const v = vel.current;

    const water = inWater(blocks, p.x, p.y, p.z);

    if (st.fly) {
      let vy = 0;
      if (!paused) {
        if (k.has('Space') || input.jumpHeld) vy += 1;
        if (k.has('ShiftLeft') || k.has('KeyC') || input.sprintHeld) {
          // в полёте shift — вниз, но если вместе с двойным назначением спринта — ок
          // различаем: если есть движение — shift вниз, иначе спринт уже учтён
          vy -= 1;
        }
        // вертикаль от джойстика? прыжок уже
      }
      const mx = dirX * speed * dt;
      const mz = dirZ * speed * dt;
      const my = vy * speed * 0.85 * dt;
      if (!collides(blocks, p.x + mx, p.y, p.z)) p.x += mx;
      if (!collides(blocks, p.x, p.y + my, p.z)) p.y += my;
      else v.set(0, 0, 0);
      if (!collides(blocks, p.x, p.y, p.z + mz)) p.z += mz;
      v.set(0, 0, 0);
      onGround.current = false;
    } else {
      // горизонтальная скорость
      const targetVX = dirX * speed;
      const targetVZ = dirZ * speed;
      const accel = onGround.current ? 14 : 5;
      v.x += (targetVX - v.x) * Math.min(1, accel * dt);
      v.z += (targetVZ - v.z) * Math.min(1, accel * dt);

      // гравитация / вода
      if (water) {
        v.y -= GRAV * 0.28 * dt;
        v.y *= 1 - 2.2 * dt;
        if ((k.has('Space') || input.jumpHeld) && !paused) v.y = Math.min(v.y + 30 * dt, 4.2);
        v.y = Math.max(-6, Math.min(5, v.y));
      } else {
        v.y -= GRAV * dt;
        v.y = Math.max(-32, v.y);
        if (!paused && (k.has('Space') || input.jumpHeld) && onGround.current) {
          v.y = JUMP;
          onGround.current = false;
          playSound('step');
        }
      }

      // интеграция по осям
      const nx = p.x + v.x * dt;
      if (!collides(blocks, nx, p.y, p.z)) p.x = nx;
      else v.x = 0;

      const nz = p.z + v.z * dt;
      if (!collides(blocks, p.x, p.y, nz)) p.z = nz;
      else v.z = 0;

      const nyy = p.y + v.y * dt;
      if (!collides(blocks, p.x, nyy, p.z)) {
        p.y = nyy;
        onGround.current = false;
      } else {
        if (v.y < -8) {
          // жёсткое приземление — звук
          playSound('step');
        }
        if (v.y < 0) onGround.current = true;
        v.y = 0;
      }
    }

    // респаун при падении
    if (p.y < -24) {
      p.set(st.spawn[0], st.spawn[1], st.spawn[2]);
      v.set(0, 0, 0);
    }
    // границы мира
    const lim = 34;
    p.x = Math.max(-lim, Math.min(lim, p.x));
    p.z = Math.max(-lim, Math.min(lim, p.z));
    p.y = Math.max(-20, Math.min(80, p.y));

    // камера
    camera.rotation.order = 'YXZ';
    camera.rotation.y = yaw.current;
    camera.rotation.x = pitch.current;
    camera.rotation.z = 0;
    camera.position.set(p.x, p.y + EYE, p.z);
    const pc = camera as THREE.PerspectiveCamera;
    if (pc.fov !== st.fov) {
      pc.fov = st.fov;
      pc.updateProjectionMatrix();
    }

    // рейкаст прицела
    if (st.started && !paused) {
      const dir = new THREE.Vector3();
      camera.getWorldDirection(dir);
      const eye = new THREE.Vector3(p.x, p.y + EYE, p.z);
      const hit = raycastVoxel(blocks, eye, dir, 7);
      if (hit) aimState.target = { x: hit.x, y: hit.y, z: hit.z, nx: hit.nx, ny: hit.ny, nz: hit.nz };
      else aimState.target = null;
    } else {
      aimState.target = null;
    }

    // fps + позиция для HUD (троттлинг)
    frames.current++;
    fpsTime.current += rawDt;
    uiTick.current += rawDt;
    if (fpsTime.current >= 0.5) {
      const fps = Math.round(frames.current / fpsTime.current);
      frames.current = 0;
      fpsTime.current = 0;
      useGame.getState().set({ fps });
    }
    if (uiTick.current > 0.15) {
      uiTick.current = 0;
      useGame.getState().set({ playerPos: [p.x, p.y, p.z] });
      // день/ночь
      if (st.autoDay) {
        let t = st.timeOfDay + rawDt * 0.004;
        if (t > 1) t -= 1;
        useGame.getState().set({ timeOfDay: t });
      }
    }
    // частицы
    if (st.particles.length > 0) st.tickParticles(dt);
  });

  return null;
}
