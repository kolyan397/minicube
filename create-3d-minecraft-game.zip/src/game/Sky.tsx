import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useGame } from './store';

function lerpColor(a: string, b: string, t: number) {
  const ca = new THREE.Color(a);
  const cb = new THREE.Color(b);
  return ca.lerp(cb, t);
}

export default function Sky() {
  const dirRef = useRef<THREE.DirectionalLight>(null!);
  const sunRef = useRef<THREE.Mesh>(null!);
  const moonRef = useRef<THREE.Mesh>(null!);
  const cloudsRef = useRef<THREE.InstancedMesh>(null!);

  const clouds = useMemo(() => {
    const arr: { x: number; z: number; s: number }[] = [];
    for (let i = 0; i < 40; i++) {
      arr.push({
        x: (Math.random() - 0.5) * 140,
        z: (Math.random() - 0.5) * 140,
        s: 4 + Math.random() * 8,
      });
    }
    return arr;
  }, []);

  const stars = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(400 * 3);
    for (let i = 0; i < 400; i++) {
      const r = 160;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI * 0.45;
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.cos(phi) + 10;
      pos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
    }
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    return g;
  }, []);

  const dummy = useMemo(() => new THREE.Object3D(), []);
  const cloudOffset = useRef(0);
  const starPoints = useRef<THREE.Points>(null!);

  useFrame((state, dt) => {
    const st = useGame.getState();
    const t = st.timeOfDay;
    const ang = (t - 0.25) * Math.PI * 2; // 0.25 восход
    const sunX = Math.cos(ang) * 90;
    const sunY = Math.sin(ang) * 90;
    const sunZ = 25;

    if (dirRef.current) {
      dirRef.current.position.set(sunX, Math.max(sunY, -40), sunZ);
      const day = THREE.MathUtils.clamp((sunY + 12) / 40, 0, 1);
      dirRef.current.intensity = 0.25 + day * 1.15;
      dirRef.current.color.set(day > 0.5 ? '#fff5e0' : '#ff9a5a');
    }
    if (sunRef.current) {
      sunRef.current.position.set(sunX, sunY, sunZ);
      (sunRef.current.material as THREE.MeshBasicMaterial).color.set('#ffdf5a');
    }
    if (moonRef.current) {
      moonRef.current.position.set(-sunX, -sunY, -sunZ);
    }

    // небо
    const scene = state.scene;
    const dayF = THREE.MathUtils.clamp((sunY + 10) / 50, 0, 1);
    const sunsetF = Math.max(0, 1 - Math.abs(sunY) / 22) * (sunY > -12 ? 1 : 0);
    let sky = lerpColor('#070b1d', '#7cb8ff', dayF);
    if (sunsetF > 0 && dayF > 0.05 && dayF < 0.7) {
      sky = sky.lerp(new THREE.Color('#ff9a56'), sunsetF * 0.55);
    }
    (scene.background as THREE.Color)?.set?.(sky);
    if (scene.background instanceof THREE.Color) scene.background.set(sky);
    else scene.background = sky;
    if (scene.fog instanceof THREE.Fog) {
      scene.fog.color.set(sky);
      scene.fog.near = 38;
      scene.fog.far = 110;
    }

    // звёзды
    const starMat = (starPoints.current?.material as THREE.PointsMaterial) || null;
    if (starMat) starMat.opacity = 1 - dayF;

    // облака дрейф
    cloudOffset.current += dt * 0.7;
    if (cloudsRef.current) {
      for (let i = 0; i < clouds.length; i++) {
        const c = clouds[i];
        let x = c.x + cloudOffset.current;
        if (x > 75) x -= 150;
        dummy.position.set(x, 30 + (i % 3), c.z);
        dummy.scale.set(c.s, 1.2, c.s * 0.6);
        dummy.updateMatrix();
        cloudsRef.current.setMatrixAt(i, dummy.matrix);
      }
      cloudsRef.current.instanceMatrix.needsUpdate = true;
    }
  });

  return (
    <>
      <fog attach="fog" args={['#7cb8ff', 38, 110]} />
      <color attach="background" args={['#7cb8ff']} />
      <hemisphereLight args={['#cfe8ff', '#6b5b3e', 0.75]} />
      <ambientLight intensity={0.35} />
      <directionalLight ref={dirRef} intensity={1.2} position={[40, 60, 25]} />

      {/* солнце */}
      <mesh ref={sunRef}>
        <sphereGeometry args={[6, 16, 16]} />
        <meshBasicMaterial color="#ffdf5a" fog={false} />
      </mesh>
      {/* луна */}
      <mesh ref={moonRef}>
        <sphereGeometry args={[4, 16, 16]} />
        <meshBasicMaterial color="#e8eefc" fog={false} />
      </mesh>

      {/* звёзды */}
      <points ref={starPoints} geometry={stars}>
        <pointsMaterial color="#ffffff" size={1.4} sizeAttenuation={false} transparent opacity={0} fog={false} />
      </points>

      {/* облака */}
      <instancedMesh ref={cloudsRef} args={[undefined, undefined, clouds.length]} frustumCulled={false}>
        <boxGeometry args={[1, 1, 1]} />
        <meshLambertMaterial color="#ffffff" transparent opacity={0.75} />
      </instancedMesh>

      {/* бесконечный океан вокруг острова */}
      <mesh position={[0, 6.2, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[500, 500]} />
        <meshLambertMaterial color="#2f6fd6" transparent opacity={0.92} />
      </mesh>
      {/* дно под миром */}
      <mesh position={[0, -0.6, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[500, 500]} />
        <meshBasicMaterial color="#1a2a1a" />
      </mesh>
    </>
  );
}
