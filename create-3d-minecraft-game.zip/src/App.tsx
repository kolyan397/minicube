import { useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { useGame } from './game/store';
import Player from './game/Player';
import Voxels from './game/Voxels';
import Sky from './game/Sky';
import HUD from './components/HUD';

export default function App() {
  const started = useGame((s) => s.started);
  const newWorld = useGame((s) => s.newWorld);
  const loadWorld = useGame((s) => s.loadWorld);
  const fov = useGame((s) => s.fov);

  useEffect(() => {
    // предгенерация мира в фоне
    const s = useGame.getState();
    if (Object.keys(s.blocks).length < 100) {
      const ok = loadWorld();
      if (!ok) newWorld(202606);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // автосейв каждые 30 сек
  useEffect(() => {
    const id = setInterval(() => {
      const st = useGame.getState();
      if (st.started && Object.keys(st.blocks).length > 100) st.saveWorld();
    }, 30000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="relative h-[100dvh] w-full select-none overflow-hidden bg-black">
      <Canvas
        dpr={[1, 1.75]}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
        camera={{ fov, near: 0.1, far: 600, position: [0.5, 14, 6.5] }}
        onCreated={({ gl }) => {
          gl.domElement.addEventListener('webglcontextlost', (e) => e.preventDefault());
        }}
      >
        <Sky />
        <Voxels />
        <Player />
      </Canvas>

      {/* виньетка */}
      {started && (
        <div className="pointer-events-none absolute inset-0 z-10 shadow-[inset_0_0_120px_rgba(0,0,0,0.35)]" />
      )}

      <HUD />
    </div>
  );
}
